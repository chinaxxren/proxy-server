use crate::cache::unit_pool::UnitPool;
use crate::config::CONFIG;
use crate::utils::error::Result;
use crate::{log_error, log_info};
use std::sync::Arc;
use tokio::fs;

pub struct CacheManager {
    unit_pool: Arc<UnitPool>,
}

impl CacheManager {
    pub fn new(unit_pool: Arc<UnitPool>) -> Self {
        Self { unit_pool }
    }

    pub async fn clean_cache(&self) -> Result<()> {
        log_info!("Cache", "开始清理缓存...");
        
        let cache_dir = CONFIG.get_cache_dir();
        if !fs::try_exists(&cache_dir).await? {
            log_info!("Cache", "缓存目录不存在");
            return Ok(());
        }

        let mut total_size = 0u64;
        let mut cleaned_count = 0u32;

        // 遍历缓存目录
        let mut entries = fs::read_dir(&cache_dir).await?;
        while let Some(entry) = entries.next_entry().await? {
            let metadata = entry.metadata().await?;
            if metadata.is_file() {
                total_size += metadata.len();
                
                // 如果文件大小为0，删除它
                if metadata.len() == 0 {
                    if let Err(e) = fs::remove_file(entry.path()).await {
                        log_error!("Cache", "删除空文件失败: {}", e);
                    } else {
                        cleaned_count += 1;
                    }
                }
            }
        }

        log_info!(
            "Cache",
            "缓存清理完成: 清理了 {} 个文件, 当前缓存总大小: {} MB",
            cleaned_count,
            total_size / 1024 / 1024
        );

        Ok(())
    }
}

impl Clone for CacheManager {
    fn clone(&self) -> Self {
        Self {
            unit_pool: self.unit_pool.clone(),
        }
    }
}