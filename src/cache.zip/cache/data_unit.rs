use serde::{Deserialize, Serialize};
use chrono::{DateTime, Utc};

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct DataUnit {
    pub ranges: Vec<(u64, u64)>,
    pub last_accessed: DateTime<Utc>,
    pub total_size: Option<u64>,
    pub cache_file: String,
    pub allocated_size: u64,
}

impl DataUnit {
    pub fn new(cache_file: String) -> Self {
        Self {
            ranges: Vec::new(),
            last_accessed: Utc::now(),
            total_size: None,
            cache_file,
            allocated_size: 0,
        }
    }

    pub fn add_range(&mut self, start: u64, end: u64) {
        // 更新访问时间
        self.last_accessed = Utc::now();

        // 如果范围列表为空，直接添加
        if self.ranges.is_empty() {
            self.ranges.push((start, end));
            self.allocated_size = end - start + 1;
            return;
        }

        // 插入新范围并合并重叠区间
        let mut new_ranges = Vec::new();
        let mut current_start = start;
        let mut current_end = end;
        let mut inserted = false;

        for &(s, e) in &self.ranges {
            if e + 1 < current_start {
                // 当前区间在新区间之前
                new_ranges.push((s, e));
            } else if s > current_end + 1 {
                // 当前区间在新区间之后
                if !inserted {
                    new_ranges.push((current_start, current_end));
                    inserted = true;
                }
                new_ranges.push((s, e));
            } else {
                // 区间有重叠，进行合并
                current_start = current_start.min(s);
                current_end = current_end.max(e);
            }
        }

        if !inserted {
            new_ranges.push((current_start, current_end));
        }

        self.ranges = new_ranges;
        
        // 更新已分配大小
        self.allocated_size = self.ranges.iter()
            .map(|(start, end)| end - start + 1)
            .sum();
    }

    pub fn contains_range(&self, start: u64, end: u64) -> bool {
        for &(s, e) in &self.ranges {
            if s <= start && e >= end {
                return true;
            }
        }
        false
    }

    pub fn overlaps_range(&self, start: u64, end: u64) -> bool {
        for &(s, e) in &self.ranges {
            if s <= end && e >= start {
                return true;
            }
        }
        false
    }

    pub fn get_missing_ranges(&self, start: u64, end: u64) -> Vec<(u64, u64)> {
        let mut missing = Vec::new();
        let mut current = start;

        // 按起始位置排序范围
        let mut sorted_ranges = self.ranges.clone();
        sorted_ranges.sort_by_key(|&(s, _)| s);

        for &(s, e) in &sorted_ranges {
            if current < s {
                missing.push((current, s - 1));
            }
            current = e + 1;
        }

        if current <= end {
            missing.push((current, end));
        }

        missing
    }
}