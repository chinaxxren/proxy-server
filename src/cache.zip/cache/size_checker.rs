use std::sync::atomic::{AtomicU64, Ordering};

pub struct SizeChecker {
    total_size: AtomicU64,
}

impl SizeChecker {
    pub fn new() -> Self {
        Self {
            total_size: AtomicU64::new(0),
        }
    }

    pub fn update_size(&self, size: u64) {
        self.total_size.store(size, Ordering::SeqCst);
    }

    pub fn get_size(&self) -> u64 {
        self.total_size.load(Ordering::SeqCst)
    }
}

impl Default for SizeChecker {
    fn default() -> Self {
        Self::new()
    }
}