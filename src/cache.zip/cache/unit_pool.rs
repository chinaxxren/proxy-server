use crate::cache::data_unit::DataUnit;
use crate::config::CONFIG;
use crate::utils::error::{ProxyError, Result};
use crate::utils::range::parse_range;
use crate::{log_error, log_info};
use std::collections::HashMap;
use std::sync::Arc;
use tokio::sync::RwLock;
use tokio::fs;
use serde_json;

pub struct UnitPool {
    pub cache_map: Arc<RwLock<HashMap<String, DataUnit>>>,
}

impl UnitPool {
    pub fn new() -> Self {
        Self {
            cache_map: Arc::new(RwLock::new(HashMap::new())),
        }
    }

    pub async fn load_cache_state(&self, url: &str) -> Result<()> {
        log_info!("Cache", "加载缓存状态: {}", url);
        let state_file = CONFIG.get_cache_state(url);
        
        // 如果状态文件不存在，创建一个新的缓存单元
        if !fs::try_exists(&state_file).await? {
            let cache_path = CONFIG.get_cache_file(url);
            let mut cache_map = self.cache_map.write().await;
            cache_map.insert(cache_path.clone(), DataUnit::new(cache_path));
            return Ok(());
        }

        // 读取状态文件
        let content = fs::read_to_string(&state_file).await?;
        let data_unit: DataUnit = serde_json::from_str(&content)
            .map_err(|e| ProxyError::Cache(format!("解析缓存状态失败: {}", e)))?;

        // 更新缓存映射
        let mut cache_map = self.cache_map.write().await;
        cache_map.insert(data_unit.cache_file.clone(), data_unit);

        Ok(())
    }

    pub async fn save_cache_state(&self, url: &str) -> Result<()> {
        let cache_path = CONFIG.get_cache_file(url);
        let state_file = CONFIG.get_cache_state(url);
        
        // 确保状态目录存在
        if let Some(parent) = std::path::Path::new(&state_file).parent() {
            fs::create_dir_all(parent).await?;
        }

        let cache_map = self.cache_map.read().await;
        if let Some(data_unit) = cache_map.get(&cache_path) {
            log_info!("Cache", "保存缓存状态: {} -> {:?}", url, data_unit);
            let content = serde_json::to_string_pretty(data_unit)
                .map_err(|e| ProxyError::Cache(format!("序列化缓存状态失败: {}", e)))?;
            fs::write(&state_file, content).await?;
        }

        Ok(())
    }

    pub async fn update_cache(&self, url: &str, range: &str) -> Result<()> {
        let (start, end) = parse_range(range)?;
        let cache_path = CONFIG.get_cache_file(url);
        
        // 更新缓存映射
        let mut cache_map = self.cache_map.write().await;
        if let Some(data_unit) = cache_map.get_mut(&cache_path) {
            data_unit.add_range(start, end);
            log_info!("Cache", "更新缓存: {} {}-{}", url, start, end);
        }
        drop(cache_map);

        // 保存状态
        self.save_cache_state(url).await?;
        
        Ok(())
    }

    pub async fn set_total_size(&self, url: &str, size: u64) -> Result<()> {
        let cache_path = CONFIG.get_cache_file(url);
        let mut cache_map = self.cache_map.write().await;
        if let Some(data_unit) = cache_map.get_mut(&cache_path) {
            data_unit.total_size = Some(size);
        }
        drop(cache_map);

        self.save_cache_state(url).await?;
        Ok(())
    }

    pub async fn is_fully_cached(&self, url: &str, range: &str) -> Result<bool> {
        let (start, end) = parse_range(range)?;
        let cache_path = CONFIG.get_cache_file(url);
        
        let cache_map = self.cache_map.read().await;
        if let Some(data_unit) = cache_map.get(&cache_path) {
            Ok(data_unit.contains_range(start, end))
        } else {
            Ok(false)
        }
    }

    pub async fn is_partially_cached(&self, url: &str, range: &str) -> Result<bool> {
        let (start, end) = parse_range(range)?;
        let cache_path = CONFIG.get_cache_file(url);
        
        let cache_map = self.cache_map.read().await;
        if let Some(data_unit) = cache_map.get(&cache_path) {
            if data_unit.overlaps_range(start, end) {
                log_info!("Cache", "部分缓存命中");
                return Ok(true);
            }
        }
        Ok(false)
    }

    pub async fn get_missing_ranges(&self, url: &str, range: &str) -> Result<Vec<(u64, u64)>> {
        let (start, end) = parse_range(range)?;
        let cache_path = CONFIG.get_cache_file(url);
        
        let cache_map = self.cache_map.read().await;
        if let Some(data_unit) = cache_map.get(&cache_path) {
            Ok(data_unit.get_missing_ranges(start, end))
        } else {
            Ok(vec![(start, end)])
        }
    }
}

impl Default for UnitPool {
    fn default() -> Self {
        Self::new()
    }
}